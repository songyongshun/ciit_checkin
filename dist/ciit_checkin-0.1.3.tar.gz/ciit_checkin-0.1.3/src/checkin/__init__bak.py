import argparse
from . import server, admin
from typing import Optional
import os

def checkin_server(host: str = "127.0.0.1", port: int = 8000, config: Optional[str] = None):
    """Start the checkin HTTP server (blocking)."""
    # ✅ 不再解析命令行参数 —— 配置将通过 /manage 页面动态传入
    # （保留 host/port 作为函数参数，便于测试或脚本调用）

    # 获取默认 room_number 仅用于启动提示（可选）
    room_number, _, _ = admin.load_classroom_config(config)
    if room_number is None:
        room_number = "1058"

    print(f"Starting checkin server on {host}:{port}")
    print(f"Default room: {room_number}. Manage config at http://{host}:{port}/manage")

    return server.run_server(host=host, port=port, room_info_path=config)